# Holmes & Watson Supreme AI
Fully integrated AI app including frontend, backend, and Supabase/Neon DB.